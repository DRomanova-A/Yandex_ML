__author__ = 'xead'
import joblib


class SentimentClassifier(object):
    def __init__(self):
        self.model = joblib.load("./PipelineDump.pkl")
        self.classes_dict = {0: "Негативный", 1: "Позитивный", -1: "Ошибка", -2: " "}

    @staticmethod
    def get_probability_words(probability):
        if probability < 0.55:
            return "neutral or uncertain"
        if probability < 0.7:
            return "probably"
        if probability > 0.95:
            return "certain"
        else:
            return ""

    def predict_text(self, text):
        if text == "":
            return -2, 0
        try:
            return self.model.predict([text])

        except:
            print ("prediction error")
            return -1, 0.8

    def predict_list(self, list_of_texts):
        try:
            print("start vectorizer")
            vectorized = self.vectorizer.transform(list_of_texts)
            print("vectorizer done")
            return self.model.predict(vectorized),\
                   self.model.predict_proba(vectorized)
        except:
            print ('prediction error')
            return None

    def get_prediction_message(self, text):
        prediction = self.predict_text(text)
        class_prediction = prediction[0]
        return self.classes_dict[class_prediction]
